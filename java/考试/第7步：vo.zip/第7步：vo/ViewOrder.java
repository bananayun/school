/**  
* @Title: ViewOrder.java  
* @Package cn.bsuc.jr.common.vo  
* @Description: TODO(用一句话描述该文件做什么)  
* @author Feri 
* @date 2018年5月31日  
* @version V1.0  
*/  
package cn.bsuc.jr.common.vo;
import java.util.List;
public class ViewOrder {
	private String id;
	private String createtime;
	private double money;
	private int flag;
	private String name;
	private String phone;
	private String detail;
	private List<ViewOrderDetail> list;//订单子项
	public List<ViewOrderDetail> getList() {
		return list;
	}
	public void setList(List<ViewOrderDetail> list) {
		this.list = list;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCreatetime() {
		return createtime;
	}
	public void setCreatetime(String createtime) {
		this.createtime = createtime;
	}
	public double getMoney() {
		return money;
	}
	public void setMoney(double money) {
		this.money = money;
	}
	public int getFlag() {
		return flag;
	}
	public void setFlag(int flag) {
		this.flag = flag;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
}