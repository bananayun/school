package cn.bsuc.jr.common.vo;

import java.util.ArrayList;

import cn.bsuc.jr.domain.Goods;

/**   
* Copyright: Copyright (c) 2018
* @ClassName: ViewGoodsIndex.java
* @Description: 该类的功能描述
* @version: v1.0.0
* @author: feri
* @date: 2018年11月25日 下午8:49:56 
* Modification History:
* Date         Author          Version            Description
*---------------------------------------------------------*
* 2018年11月25日       feri           v1.0.0               修改原因
*/
public class ViewGoodsIndex {
	private int id;
	private ArrayList<Goods> data;
	

}
