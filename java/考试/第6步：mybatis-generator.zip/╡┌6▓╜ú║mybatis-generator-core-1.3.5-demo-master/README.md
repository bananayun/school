# mybatis-generator-core-1.3.5-demo
mybatis-generator-core-1.3.5
