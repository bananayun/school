package com.qfedu.service.impl;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.qfedu.dao.UserAddressDao;
import com.qfedu.domain.UserAddress;
import com.qfedu.service.UserAddressService;
@Service
public class UserAddressServiceImpl implements UserAddressService{
	@Autowired
	private UserAddressDao dao;
	//新增收货地址
	@Override
	public boolean insert(UserAddress ua) {
		// TODO Auto-generated method stub
		return dao.insert(ua)>0;
	}
	//查询收货地址
	@Override
	public List<UserAddress> queryByUid(int uid) {
		// TODO Auto-generated method stub
		return dao.queryByUid(uid);
	}
	//修改地址
	@Override
	public boolean update(UserAddress ua) {
		// TODO Auto-generated method stub
		return dao.update(ua)>0;
	}
	//删除地址信息
	@Override
	public int deleteAddress(int id) {
		// TODO Auto-generated method stub
		return dao.deleteById(id);
	}
	//修改为默认
	@Override
	public int updateDea(int id,int uid) {
		List<UserAddress> queryByUid = queryByUid(uid);
		if(queryByUid != null && !queryByUid.isEmpty()) {
			for(UserAddress userAddress : queryByUid) {
				if(userAddress.getFlag() == 3) {
					dao.updateDea(userAddress.getId(),1);//将以前的默认修改为普通
				}
			}
		}
		return dao.updateDea(id,3);
	}

}
