﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace tour.manage
{
    public partial class liuyan : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string sql = "";

            if (!IsPostBack)
            {
                string action = Request["action"];

                if (action == "edit")
                {
                    Label1.Text = "回复留言";

                    string id = Request["id"];

                    sql = "select * from t_liuyan where id=" + id;

                    DataTable dt = SQLHelper.ExecuteDataTable(sql);

                    ltitle.Text = Convert.ToString(dt.Rows[0]["ltitle"]);
                    lcontent.Text = Convert.ToString(dt.Rows[0]["lcontent"]);

                    ltitle.ReadOnly = true;
                    lcontent.ReadOnly = true;

                }
                else if (action == "show")
                {
                    Label1.Text = "查看详情";

                    string id = Request["id"];
                    sql = "select * from t_liuyan where id=" + id;

                    DataTable dt = SQLHelper.ExecuteDataTable(sql);

                    ltitle.Text = Convert.ToString(dt.Rows[0]["ltitle"]);
                    lcontent.Text = Convert.ToString(dt.Rows[0]["lcontent"]);
                    hcontent.Text = Convert.ToString(dt.Rows[0]["hcontent"]);

                    ltitle.ReadOnly = true;
                    lcontent.ReadOnly = true;
                    hcontent.ReadOnly = true;

                    Button1.Visible = false;

                }
                else if (action == "del")
                {
                    string id = Request["id"];

                    sql = " delete from t_liuyan where id=" + id;

                    SQLHelper.ExecuteNonQuery(sql);

                    Response.Write("<script language=javascript>alert('操作成功');window.location.href='liuyanlist.aspx';</script>");

                }
                else
                {

                    throw new Exception("action错误" + action);
                }


            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string sql = "";

            if (!IsValid)
            {
                return;
            }

            string action = Request["action"];

            if (action == "edit")
            {
                string id = Request["id"];

                sql = "update t_liuyan set hcontent='" + hcontent.Text + "', htime='" + Util.getTime() + "' ,status='已回复' where id=" + id;

                SQLHelper.ExecuteNonQuery(sql);

                Response.Write("<script language=javascript>alert('操作成功');window.location.href='liuyanlist.aspx';</script>");

            }
            else
            {
                throw new Exception("action错误" + action);
            }

        }
    }
}