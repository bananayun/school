﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace tour.manage
{
    public partial class tourpic : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string sql = "";

            string tourid = Request["tourid"];

            if (!IsPostBack)
            {
                string action = Request["action"];

                if (action == "add")
                {
                    Label1.Text = "上传旅游图片";
                }
                else if (action == "del")
                {
                    string id = Request["id"];

                    sql = "select count(1) from t_tourpic where status='主图' and id=" + id + "  ";

                    int count = Convert.ToInt32(SQLHelper.ExecuteScalar(sql));

                    if (count > 0)
                    {
                        Response.Write("<script language=javascript>alert('操作失败，主图不能直接删除');window.location.href='tourpiclist.aspx?tourid=" + tourid + "';</script>");

                    }
                    else
                    {

                        sql = " delete from t_tourpic where id=" + id;

                        SQLHelper.ExecuteNonQuery(sql);

                        Response.Write("<script language=javascript>alert('操作成功');window.location.href='tourpiclist.aspx?tourid=" + tourid + "';</script>");

                    }


                }
                else if (action == "tuijian")
                {
                    string id = Request["id"];

                    sql = "update t_tourpic set status='从图' where tourid=" + tourid;

                    SQLHelper.ExecuteNonQuery(sql);

                    sql = " update  t_tourpic set status='主图' where id=" + id;

                    SQLHelper.ExecuteNonQuery(sql);

                    sql = " select * from t_tourpic where id= " + id;

                    DataTable dt = SQLHelper.ExecuteDataTable(sql);
                    string pic = Convert.ToString(dt.Rows[0]["pic"]);

                    sql = "update t_tour set pic ='" + pic + "' where id=  " + tourid;

                    SQLHelper.ExecuteNonQuery(sql);

                    Response.Write("<script language=javascript>alert('操作成功');window.location.href='tourpiclist.aspx?tourid=" + tourid + "';</script>");

                }
                else
                {

                    throw new Exception("action错误" + action);
                }
            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string tourid = Request["tourid"];

            string sql = "";

            if (!IsValid)
            {
                return;
            }

            string action = Request["action"];

            if (action == "add")
            {

                string filename = "";

                if (FileUpload1.HasFile)//用户是否选择了文件
                {
                    string uploadPath = Server.MapPath("/upload/");

                    //定义上传文件的格式
                    string[] arrExtension = { ".jpg", ".gif", ".png" };

                    //取得上传的文件名
                    filename = FileUpload1.FileName;
                    // 取得上传文件的扩展名 
                    string strExtension = filename.Substring(filename.LastIndexOf("."));

                    //判断上传文件是否合法
                    int flag = 0;
                    for (int i = 0; i < arrExtension.Length; i++)
                    {

                        if (strExtension.Equals(arrExtension[i]))
                        {
                            flag = 1;
                        }

                    }
                    if (flag == 0)
                    {
                        Response.Write("<script language=javascript>alert('上传失败，上传的文件必须为jpg或者gif或者png格式');window.location.href='housepic.aspx?action=add&tourid=" + tourid + "';</script>");
                        return;
                    }
                    string name = Util.getBianhao();

                    filename = name + strExtension;

                    FileUpload1.SaveAs(uploadPath + filename);

                }


                sql = "select count(1) from t_tourpic where status='主图' and tourid=" + tourid + "  ";

                int count = Convert.ToInt32(SQLHelper.ExecuteScalar(sql));

                string status = "";

                if (count > 0)
                {
                    status = "从图";
                }
                else
                {
                    status = "主图";
                }


                sql = @"insert into t_tourpic (tourid,pic,status) 
                        values  (" + tourid + ",'" + filename + "','" + status + "')";

                SQLHelper.ExecuteNonQuery(sql);

                if (status.Equals("主图"))
                {
                    sql = "update t_tour set pic ='" + filename + "' where id=  " + tourid;

                    SQLHelper.ExecuteNonQuery(sql);

                }

                Response.Write("<script language=javascript>alert('操作成功');window.location.href='tourpiclist.aspx?tourid=" + tourid + "';</script>");


            }



        }
    }
}