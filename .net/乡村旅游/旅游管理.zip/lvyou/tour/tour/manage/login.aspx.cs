﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace tour.manage
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button1_Click1(object sender, EventArgs e)
        {
            string username = txtusername.Text;
            string password = txtpassword.Text;


            string sql = "select count(1) from t_user where username='" + username + "' and password='" + password + "' and role=1 ";

            int count = Convert.ToInt32(SQLHelper.ExecuteScalar(sql));

            if (count <= 0)
            {
                Response.Write("<script language=javascript>alert('登录失败，用户名或密码错误');window.location.href='login.aspx';</script>");
                return;
            }

            sql = "select * from t_user where username='" + username + "' and password='" + password + "' and role=1  ";

            DataTable dt = SQLHelper.ExecuteDataTable(sql);

            Session["username"] = Convert.ToString(dt.Rows[0]["username"]);
            Session["uid"] = Convert.ToString(dt.Rows[0]["id"]);

            Response.Write("<script language=javascript>alert('登录成功');window.location.href='index.aspx';</script>");
        }
    }
}