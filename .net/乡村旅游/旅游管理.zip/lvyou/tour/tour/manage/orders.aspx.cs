﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace tour.manage
{
    public partial class orders : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string sql = "";

            if (!IsPostBack)
            {
                string action = Request["action"];
                
                if (action == "fail")
                {
                    string id = Request["id"];

                    sql = " update t_orders set status='生成失败' where id=" + id;

                    SQLHelper.ExecuteNonQuery(sql);

                    Response.Write("<script language=javascript>alert('操作成功');window.location.href='orderslist.aspx';</script>");

                }

            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string sql = "";

            if (!IsValid)
            {
                return;
            }

            string action = Request["action"];

            if (action == "success")
            {
                string id = Request["id"];

                sql = "update t_orders set status='生成成功' ,riqi='"+riqi.Text+"'  where id=" + id;

                SQLHelper.ExecuteNonQuery(sql);

                sql = " select * from t_orders where id= " + id;

                DataTable dt = SQLHelper.ExecuteDataTable(sql);
                int tourid = Convert.ToInt32(dt.Rows[0]["tourid"]);
                int renshu = Convert.ToInt32(dt.Rows[0]["renshu"]);

                sql = " update  t_tour set buys= buys+" + renshu + " where id=" + tourid;

                SQLHelper.ExecuteNonQuery(sql);


                Response.Write("<script language=javascript>alert('操作成功');window.location.href='orderslist.aspx';</script>");

            }
            else
            {
                throw new Exception("action错误" + action);
            }

        }
    }
}