﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace tour.manage
{
    public partial class user : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string sql = "";

            if (!IsPostBack)
            {
                string action = Request["action"];

                if (action == "del")
                {
                    string id = Request["id"];

                    sql = " delete from t_user where id=" + id;

                    SQLHelper.ExecuteNonQuery(sql);

                    Response.Write("<script language=javascript>alert('操作成功');window.location.href='userlist.aspx';</script>");

                }
                else
                {

                    throw new Exception("action错误" + action);
                }


            }
        }

       
    }
}