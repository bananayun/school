﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace tour.manage
{
    public partial class tour : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string sql = "";

            if (!IsPostBack)
            {
                string action = Request["action"];

                if (action == "add")
                {
                    Label1.Text = "添加新旅游";
                }
                else if (action == "edit")
                {
                    Label1.Text = "编辑旅游";

                    string id = Request["id"];

                    sql = "select * from t_tour where id=" + id;

                    DataTable dt = SQLHelper.ExecuteDataTable(sql);

                    biaoti.Text = Convert.ToString(dt.Rows[0]["biaoti"]);
                    leixing.Text = Convert.ToString(dt.Rows[0]["leixing"]);
                    city.Text = Convert.ToString(dt.Rows[0]["city"]);
                    xingcheng.Text = Convert.ToString(dt.Rows[0]["xingcheng"]);
                    jingse.Text = Convert.ToString(dt.Rows[0]["jingse"]);
                    price.Text = Convert.ToString(dt.Rows[0]["price"]);
                    shuoming.Text = Convert.ToString(dt.Rows[0]["shuoming"]);


                }
                else if (action == "show")
                {
                    Label1.Text = "查看旅游信息";

                    string id = Request["id"];
                    sql = "select * from t_tour where id=" + id;

                    DataTable dt = SQLHelper.ExecuteDataTable(sql);

                    biaoti.Text = Convert.ToString(dt.Rows[0]["biaoti"]);
                    leixing.Text = Convert.ToString(dt.Rows[0]["leixing"]);
                    city.Text = Convert.ToString(dt.Rows[0]["city"]);
                    xingcheng.Text = Convert.ToString(dt.Rows[0]["xingcheng"]);
                    jingse.Text = Convert.ToString(dt.Rows[0]["jingse"]);
                    price.Text = Convert.ToString(dt.Rows[0]["price"]);
                    shuoming.Text = Convert.ToString(dt.Rows[0]["shuoming"]);

                    biaoti.ReadOnly = true;
                    leixing.Enabled = false;
                    city.ReadOnly = true;
                    xingcheng.ReadOnly = true;
                    jingse.ReadOnly = true;
                    price.ReadOnly = true;
                    shuoming.ReadOnly = true;

                    Button1.Visible = false;

                }
                else if (action == "del")
                {
                    string id = Request["id"];

                    sql = " delete from t_tour where id=" + id;

                    SQLHelper.ExecuteNonQuery(sql);

                    Response.Write("<script language=javascript>alert('操作成功');window.location.href='tourlist.aspx';</script>");

                }
                else if (action == "tj1")
                {
                    string id = Request["id"];

                    sql = " update  t_tour set tuijian='已推荐' where id=" + id;

                    SQLHelper.ExecuteNonQuery(sql);

                    Response.Write("<script language=javascript>alert('操作成功');window.location.href='tourlist.aspx';</script>");

                }
                else if (action == "tj2")
                {
                    string id = Request["id"];

                    sql = " update  t_tour set tuijian='未推荐' where id=" + id;

                    SQLHelper.ExecuteNonQuery(sql);

                    Response.Write("<script language=javascript>alert('操作成功');window.location.href='tourlist.aspx';</script>");

                }
                else
                {

                    throw new Exception("action错误" + action);
                }


            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string sql = "";

            if (!IsValid)
            {
                return;
            }

            string action = Request["action"];

            if (action == "add")
            {
                sql = @"insert into t_tour (biaoti,leixing,ctime,vist,buys,xingcheng,jingse,price,shuoming,tuijian,city) 
                      values  ('" + biaoti.Text + "','" + leixing.Text + "','" + Util.getRiqi() + "',0,0,'" + xingcheng.Text
                                  + "','" + jingse.Text + "'," + price.Text + ",'" + shuoming.Text+ "','未推荐','"+city.Text+"')";

                SQLHelper.ExecuteNonQuery(sql);

                Response.Write("<script language=javascript>alert('操作成功');window.location.href='tourlist.aspx';</script>");
            }
            else if (action == "edit")
            {
                string id = Request["id"];

                sql = "update t_tour set biaoti='" + biaoti.Text + "',leixing='" + leixing.Text + "',xingcheng='" + xingcheng.Text
                    + "',jingse='" + jingse.Text + "',price=" + price.Text + ",shuoming='" + shuoming.Text 
                    + "',city='"+city.Text+"' where id=" + id;

                SQLHelper.ExecuteNonQuery(sql);

                Response.Write("<script language=javascript>alert('操作成功');window.location.href='tourlist.aspx';</script>");

            }
            else
            {
                throw new Exception("action错误" + action);
            }

        }
    }
}