﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace tour.manage
{
    public partial class zixun : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string sql = "";

            if (!IsPostBack)
            {
                string action = Request["action"];

                if (action == "add")
                {
                    Label1.Text = "添加新资讯";
                }
                else if (action == "edit")
                {
                    Label1.Text = "编辑资讯";

                    string id = Request["id"];

                    sql = "select * from t_zixun where id=" + id;

                    DataTable dt = SQLHelper.ExecuteDataTable(sql);

                    biaoti.Text = Convert.ToString(dt.Rows[0]["biaoti"]);
                    neirong.Text = Convert.ToString(dt.Rows[0]["neirong"]);


                }
                else if (action == "show")
                {
                    Label1.Text = "查看资讯";

                    string id = Request["id"];
                    sql = "select * from t_zixun where id=" + id;

                    DataTable dt = SQLHelper.ExecuteDataTable(sql);

                    biaoti.Text = Convert.ToString(dt.Rows[0]["biaoti"]);
                    neirong.Text = Convert.ToString(dt.Rows[0]["neirong"]);

                    biaoti.ReadOnly = true;
                    neirong.ReadOnly = true;

                    Button1.Visible = false;

                }
                else if (action == "del")
                {
                    string id = Request["id"];

                    sql = " delete from t_zixun where id=" + id;

                    SQLHelper.ExecuteNonQuery(sql);

                    Response.Write("<script language=javascript>alert('操作成功');window.location.href='zixunlist.aspx';</script>");

                }
                else
                {

                    throw new Exception("action错误" + action);
                }


            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string sql = "";

            if (!IsValid)
            {
                return;
            }

            string action = Request["action"];

            if (action == "add")
            {
                sql = @"insert into t_zixun (biaoti,neirong,ctime) values  ('" + biaoti.Text + "','" + neirong.Text + "','" + Util.getTime() + "')";

                SQLHelper.ExecuteNonQuery(sql);

                Response.Write("<script language=javascript>alert('操作成功');window.location.href='zixunlist.aspx';</script>");
            }
            else if (action == "edit")
            {
                string id = Request["id"];

                sql = "update t_zixun set biaoti='" + biaoti.Text + "', neirong='" + neirong.Text + "' where id=" + id;

                SQLHelper.ExecuteNonQuery(sql);

                Response.Write("<script language=javascript>alert('操作成功');window.location.href='zixunlist.aspx';</script>");

            }
            else
            {
                throw new Exception("action错误" + action);
            }

        }
    }
}