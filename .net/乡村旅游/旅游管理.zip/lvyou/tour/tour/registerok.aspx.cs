﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace tour
{
    public partial class registerok : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string username = Request["username"];

            //判断该用户是否已经注册
            string sql = "select count(1) from t_user where username='" + username + "' ";

            int count = Convert.ToInt32(SQLHelper.ExecuteScalar(sql));

            if (count > 0)
            {

                Response.Write("<script language=javascript>alert('注册失败，该用户名已经存在');window.location.href='register.aspx';</script>");
                return;
            }

            string password = Request["password"];
            string name = Request["name"];
            int role = 2;//2表示用户
            string tel = Request["tel"];
            string address = Request["address"];
            string ctime = Util.getTime();

            //注册的sql语句
            sql = @"insert into t_user(username,password,name,role,tel,address,ctime) 
            values('" + username + "','" + password + "','" + name + "'," + role + ",'"
                     + tel + "','" + address + "','" + ctime + "')";

            SQLHelper.ExecuteNonQuery(sql);

            Response.Write("<script language=javascript>alert('注册成功');window.location.href='login.aspx';</script>");
        }
    }
}