﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace tour
{
    public partial class loginok : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            string username = Request["username"];
            string password = Request["password"];

            //用户登录sql
            string sql = "select * from t_user where role=2 and username='" + username
                + "' and password= '" + password + "'  ";

            DataTable dt = SQLHelper.ExecuteDataTable(sql);

            if (dt.Rows.Count <= 0)
            {
                Response.Write("<script language=javascript>alert('登录失败，用户名或者密码错误!');window.location.href='login.aspx';</script>");
                return;
            }

            DataRow row = dt.Rows[0];

            Session["qiantai"] = username;
            Response.Write("<script language=javascript>alert('登录成功');window.location.href='index.aspx';</script>");
            return;

        }
    }
}