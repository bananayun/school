﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace tour
{
    public partial class tourshow : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string id = Request["id"];

            PagedDataSource Pgds = new PagedDataSource();

            DataTable dt = SQLHelper.ExecuteDataTable("select * from t_tour where id= " + id);

            Pgds.DataSource = dt.DefaultView;

            tourRepeater.DataSource = Pgds;
            tourRepeater.DataBind();

            //点击数加一
            string sql = " update  t_tour set vist= vist+1 where id=" + id;

            SQLHelper.ExecuteNonQuery(sql);

            //旅游图片
            dt = SQLHelper.ExecuteDataTable(" select * from t_tourpic where tourid=" + id + "  order by status desc ");

            Pgds.DataSource = dt.DefaultView;

            tourpicRepeater.DataSource = Pgds;
            tourpicRepeater.DataBind();
        }
    }
}