﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace tour
{
    public partial class ordersshow : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string id = Request["id"];

            PagedDataSource Pgds = new PagedDataSource();

            DataTable dt = SQLHelper.ExecuteDataTable("select * from t_orders where id= " + id);

            Pgds.DataSource = dt.DefaultView;

            Repeater1.DataSource = Pgds;
            Repeater1.DataBind();
        }
    }
}