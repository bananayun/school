﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace tour
{
    public partial class ordersdel : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string id = Request["id"];

            string sql = " select * from t_orders where id= " + id;

            DataTable dt = SQLHelper.ExecuteDataTable(sql);

            string status = Convert.ToString(dt.Rows[0]["status"]);

            if ("已取消".Equals(status))
            {
                sql = " delete from   t_orders where id=" + id;

                SQLHelper.ExecuteNonQuery(sql);

                Response.Write("<script language=javascript>alert('操作成功');window.location.href='orderslist3.aspx';</script>");
            }
            else
            {

                Response.Write("<script language=javascript>alert('操作失败，只有已取消的订单才能删除');window.location.href='orderslist3.aspx';</script>");
            }

        }
    }
}