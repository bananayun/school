﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace tour
{
    public partial class liuyanok : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            string username = Convert.ToString(Session["qiantai"]);

            string ltitle = Request["ltitle"];
            string lcontent = Request["lcontent"];
            string ctime = Util.getTime();

            //生成订单sql语句
            string sql = @"insert into t_liuyan(ltitle,lcontent,ctime,status,username) 
            values('" + ltitle + "','" + lcontent + "','" + ctime + "','处理中','" + username + "')";

            SQLHelper.ExecuteNonQuery(sql);


            Response.Write("<script language=javascript>alert('操作成功');window.location.href='liuyanlist.aspx';</script>");
        }
    }
}