﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace tour
{
    public partial class ordersadd : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {


            if (Session["qiantai"]==null)
            {
                Response.Write("<script language=javascript>alert('请先登录');window.location.href='login.aspx';</script>");
                return;
            }

            string tourid = Request["tourid"];

            PagedDataSource Pgds = new PagedDataSource();

            DataTable dt = SQLHelper.ExecuteDataTable("select * from t_tour where id= " + tourid);

            Pgds.DataSource = dt.DefaultView;

            tourRepeater.DataSource = Pgds;
            tourRepeater.DataBind();
        }
    }
}