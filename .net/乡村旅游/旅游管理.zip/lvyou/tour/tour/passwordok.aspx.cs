﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace tour
{
    public partial class passwordok : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string password = Request["password"];

            string password2 = Request["password2"];



            string username = Convert.ToString(Session["qiantai"]);

            if (username == null)
            {

                Response.Write("<script language=javascript>alert('登录超时,请重新登录');window.location.href='login.aspx';</script>");
                return;

            }

            string sql = "select count(1) from t_user where username='" + username + "' and password='" + password + "' ";

            int count = Convert.ToInt32(SQLHelper.ExecuteScalar(sql));

            if (count > 0)
            {
                sql = " update t_user set password='" + password2 + "'  where username = '" + username + "' ";
                SQLHelper.ExecuteNonQuery(sql);
                Response.Write("<script language=javascript>alert('操作成功');window.location.href='password.aspx';</script>");

            }
            else
            {
                Response.Write("<script language=javascript>alert('原密码不正确，操作失败');window.location.href='password.aspx';</script>");

            }
        }
    }
}