﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
//工具类
namespace tour
{
    public class Util
    {

        //获取当前时间
        public static string getTime(){

            string time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            return time;
        }

        //获取当前日期
        public static string getRiqi() {

            string riqi = DateTime.Now.ToString("yyyy-MM-dd");

            return riqi;
        }

        //获取编号
        public static string getBianhao(){
            DateTime t1 = new DateTime();
            t1 = Convert.ToDateTime(("2010-01-01 08:00:00"));
            string bianhao = ((System.DateTime.Now.Ticks - t1.Ticks) / 10000).ToString();
            return bianhao;
        }


        public static string getYW(string status) {

            string wu = "peitao-item pc_zfdy_fypt_click";
            string you = "peitao-item has";

            string result = "";
            if (status == "有")
            {
                result = you;
            }
            else
            {
                result = wu;
            }

            return result;
        }
        

    }
}