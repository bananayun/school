﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace tour
{
    public partial class ordersquxiao : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string id = Request["id"];

            string sql = " select * from t_orders where id= " + id;

            DataTable dt = SQLHelper.ExecuteDataTable(sql);

            string status = Convert.ToString(dt.Rows[0]["status"]);

            if ("处理中".Equals(status))
            {
                sql = " update  t_orders set status= '已取消' where id=" + id;

                SQLHelper.ExecuteNonQuery(sql);

                Response.Write("<script language=javascript>alert('操作成功');window.location.href='orderslist2.aspx';</script>");
            }
            else {

                Response.Write("<script language=javascript>alert('操作失败，只有处理中才能取消订单');window.location.href='orderslist2.aspx';</script>");
            }

        }
    }
}