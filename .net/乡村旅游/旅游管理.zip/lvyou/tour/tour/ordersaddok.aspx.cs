﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace tour
{
    public partial class ordersaddok : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            string ordersid = Util.getBianhao();
            string username = Convert.ToString(Session["qiantai"]);

            string name = Request["name"];
            string tel = Request["tel"];
            string renshu = Request["renshu"];
            string remark = Request["remark"];

            string tourid = Request["tourid"];

            string sql = " select * from t_tour where id= " + tourid;

            DataTable dt = SQLHelper.ExecuteDataTable(sql);
            double price = Convert.ToDouble(dt.Rows[0]["price"]);
            string tourbiaoti = Convert.ToString(dt.Rows[0]["biaoti"]);

            double totalprice = price * Convert.ToInt32(renshu);
            string ctime = Util.getTime();


            //生成订单sql语句
            sql = @"insert into t_orders(ordersid,username,tel,price,renshu,totalprice,tourid,tourbiaoti,ctime,status,remark,name) 
            values('" + ordersid + "','" + username + "','" + tel + "'," + price + "," + renshu + ","
                     + totalprice + "," + tourid + ",'" + tourbiaoti + "','" + ctime + "','处理中','" + remark + "','"+name+"')";

            SQLHelper.ExecuteNonQuery(sql);


            Response.Write("<script language=javascript>alert('操作成功');window.location.href='orderslist.aspx';</script>");
        }
    }
}